﻿namespace InternalsViewer.Internals.Compression;

public enum CompressionInfoStructure
{
    None,
    Header,
    Anchor,
    Dictionary
}