﻿namespace InternalsViewer.Internals.Connections.Backup;

public class BackupConnectionTypeConfig() : ConnectionTypeConfig
{
    public string Filename { get; set; } = string.Empty;
}