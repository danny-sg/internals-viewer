﻿namespace InternalsViewer.Internals.Connections.File;

public class FileConnectionTypeConfig: ConnectionTypeConfig
{
    public string Filename { get; set; } = string.Empty;
}