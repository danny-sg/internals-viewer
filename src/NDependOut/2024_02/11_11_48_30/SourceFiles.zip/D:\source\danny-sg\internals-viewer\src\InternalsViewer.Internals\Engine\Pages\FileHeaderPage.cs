﻿namespace InternalsViewer.Internals.Engine.Pages;

public class FileHeaderPage : DataPage;