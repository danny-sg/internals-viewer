﻿namespace InternalsViewer.Internals.Engine.Pages;

public class LobPage : Page
{

}