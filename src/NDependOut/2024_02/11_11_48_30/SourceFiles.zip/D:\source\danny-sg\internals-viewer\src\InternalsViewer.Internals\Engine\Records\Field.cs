﻿namespace InternalsViewer.Internals.Engine.Records;

public class Field : DataStructure;