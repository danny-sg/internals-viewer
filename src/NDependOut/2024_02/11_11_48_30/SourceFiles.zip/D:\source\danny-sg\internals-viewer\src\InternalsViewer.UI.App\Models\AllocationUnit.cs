﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace InternalsViewer.UI.App.Models;

public class AllocationUnit: ObservableObject
{
}