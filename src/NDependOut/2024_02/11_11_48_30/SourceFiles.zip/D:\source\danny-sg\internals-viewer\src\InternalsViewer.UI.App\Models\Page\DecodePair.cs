﻿namespace InternalsViewer.UI.App.Models.Page;

internal class DecodePair
{
    public string DataType { get; set; } = string.Empty;

    public string Value { get; set; } = string.Empty;
}
