﻿namespace InternalsViewer.UI.App.ViewModels.Tabs;

public enum TabType
{
    Database, 
    Page,
    Connect
}