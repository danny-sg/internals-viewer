﻿namespace InternalsViewer.Internals.Connections;

public abstract class ConnectionTypeConfig;