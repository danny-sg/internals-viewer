﻿namespace InternalsViewer.Internals.Engine.Pages;

public abstract class Page : PageData;