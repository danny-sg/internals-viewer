﻿namespace InternalsViewer.Internals.Engine.Records.Blob.BlobPointers;

public enum BlobFieldType
{
    LobPointer = 0x00,
    LobRoot = 0x04,
    RowOverflow = 0x02
}