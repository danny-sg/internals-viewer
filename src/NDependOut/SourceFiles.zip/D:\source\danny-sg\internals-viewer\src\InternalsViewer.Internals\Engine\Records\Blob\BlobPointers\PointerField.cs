﻿namespace InternalsViewer.Internals.Engine.Records.Blob.BlobPointers;

public class PointerField : BlobField;