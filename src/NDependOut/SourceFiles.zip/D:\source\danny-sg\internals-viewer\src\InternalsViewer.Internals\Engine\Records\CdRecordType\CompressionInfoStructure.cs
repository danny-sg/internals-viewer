﻿namespace InternalsViewer.Internals.Engine.Records.ColumnDescriptor;

public enum CompressionInfoStructure
{
    None,
    Header,
    Anchor,
    Dictionary
}