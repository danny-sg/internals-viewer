﻿using InternalsViewer.Internals.Annotations;

namespace InternalsViewer.Internals.Engine.Records;

public class Field : DataStructure;