﻿namespace InternalsViewer.Internals.Engine.Records.Index;

public enum NodeType
{
    Node,
    Leaf,
    Root,
}