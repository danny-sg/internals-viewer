﻿namespace InternalsViewer.Internals.Metadata;

public class TransactionLogEntry
{
}
