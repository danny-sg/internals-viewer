// Global using directives

global using Microsoft.UI.Xaml;