namespace InternalsViewer.UI.App.Views.Connect;

public sealed partial class ConnectBackupPage
{
    public ConnectBackupPage()
    {
        InitializeComponent();
    }
}
